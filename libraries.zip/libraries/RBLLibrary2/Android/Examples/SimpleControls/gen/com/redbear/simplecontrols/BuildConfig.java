/** Automatically generated file. DO NOT MODIFY */
package com.redbear.simplecontrols;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}