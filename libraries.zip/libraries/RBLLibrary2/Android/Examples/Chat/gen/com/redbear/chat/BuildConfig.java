/** Automatically generated file. DO NOT MODIFY */
package com.redbear.chat;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}